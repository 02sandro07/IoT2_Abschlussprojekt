import time
import board
import analogio
import digitalio
import pwmio
import mywifi
import mymqtt
import os
import microcontroller

#----------------- Definitions -----------------

analog_pin = board.GP28  # oder board.GP28

# Configure the room pins
led1_pin = board.GP21
led1_pwm = pwmio.PWMOut(led1_pin)
led2_pin = board.GP20
led2_pwm = pwmio.PWMOut(led2_pin)
led3_pin = board.GP19
led3_pwm = pwmio.PWMOut(led3_pin)

# Configure the sun pin
sun_pin = board.GP18
sun_pwm = pwmio.PWMOut(sun_pin)


#Connect to the MQTT Browser
mywifi.connect_wifi()
mqtt_client = mymqtt.connect_mqtt()

# Erstelle ein AnalogIn-Objekt für den ausgewählten Pin
analog_in = analogio.AnalogIn(analog_pin)

#Define a list of 100 values for the light density
light_densitiy_list = []
#Define a Publish rate
publish_rate = 0
publish_rate_max = 2000
# Set a Array Value
calc_light_const = 500

#----------------- MQTT -----------------

mqtt_client.publish("iot/Project_light_const/$Name", "Konstantlichsteuerung", retain = True)
mqtt_client.publish("iot/Project_light_const/$Ersteller", "Posch, Streicher, Zischg", retain = True)
mqtt_client.publish("iot/Project_light_const/$state", "not ready", retain = True)
mqtt_client.publish("iot/Project_light_const/$$nodes", "Lichtintensität, Lichtkontrolle", retain = True)

output_feed_exception = "iot/Project_light_const/error"
output_feed_light_densitiy = "iot/Project_light_const/light_densitiy"
output_feed_light_densitiy_brightness = "iot/Project_light_const/light_densitiy/brightness"
output_feed_is_light = "iot/Project_light_const/is_light"

#----------------- Functions -----------------

# Define the calculation of the lights densitiy in lux
def lux(analog_value):
    return analog_value * 0.032 - 17.166

def get_light_density_levels():
    # Read the limits for the light density from the MQTT Browser
    # If the limits can not be read, set the default value to 1000
    light_densitiy_level_max = 600
    light_densitiy_level_min = 400

    return light_densitiy_level_max, light_densitiy_level_min
    

def light_density():
    # Read the light density from the sensor
    lux_value = lux(analog_in.value)
    # Add the new value to the list
    light_densitiy_list.append(lux_value)
    # If the list has more than 100 values, remove the first value
    if len(light_densitiy_list) > calc_light_const:
        light_densitiy_list.pop(0)
    # Calculate the average of the last 100 values
    light_densitiy = sum(light_densitiy_list) / len(light_densitiy_list)
    return light_densitiy

# Map a value from one range to another
def map_value(value, in_min, in_max, out_min, out_max):
    return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

# Set LED brightness based on light density
def set_led_brightness(lux_value, min_lux, max_lux):
    brightness = int(map_value(lux_value, min_lux, max_lux, 0, 65535))
    led1_pwm.duty_cycle = brightness
    led2_pwm.duty_cycle = brightness
    led3_pwm.duty_cycle = brightness   


# Function to control the brightness of the sun_pin
def sun():
    # Define the time it takes to transition from minimal to maximal brightness and vice versa
    transition_time = 60  # Adjust this value based on the desired transition time in seconds

    # Calculate the brightness based on the current time and transition time
    brightness = int(map_value(time.monotonic() % (2 * transition_time), 0, transition_time * 2, 0, 65535))

    # Set the brightness of the sun_pin
    sun_pwm.duty_cycle = brightness

    
#----------------- Homie-Setup -----------------

mqtt_client.publish("iot/Project_light_const/$state", "ready", retain = True)

mqtt_client.publish("iot/Project_light_const/light_densitiy/$Name", "Lichtintensität", retain = True)
mqtt_client.publish("iot/Project_light_const/light_densitiy/$Einheit", "Lux", retain = True)
mqtt_client.publish("iot/Project_light_const/light_densitiy/$Datentyp", "int", retain = True)

mqtt_client.publish("iot/Project_light_const/is_light/$Name", "Lichtkontrolle", retain = True)
mqtt_client.publish("iot/Project_light_const/is_light/$Einheit", "None", retain = True)
mqtt_client.publish("iot/Project_light_const/is_light/$Datentyp", "Bool", retain = True)

#----------------- Main -----------------
while True: 

    
    # Read the limits for the light density from the MQTT Browser 
    light_densitiy_level_max, light_densitiy_level_min = get_light_density_levels()
    
    try:    
        # Check the light density
        lux_value = light_density()
        # Call the sun() function to control the brightness of the sun_pin
        sun()
        #If the light density is between the limits, turn the light ON
        if lux_value < light_densitiy_level_max and lux_value > light_densitiy_level_min:
            publish_rate += 1
            # If the light is not too bright, turn it ON. 
            set_led_brightness(lux_value, light_densitiy_level_max, light_densitiy_level_min)
            # Publish the light status to the MQTT Browser
            if publish_rate == publish_rate_max:
                mqtt_client.publish(output_feed_is_light, "true", retain = True)
                mqtt_client.publish(output_feed_light_densitiy, lux_value, retain = True)
                mqtt_client.publish(output_feed_light_densitiy_brightness, led1_pwm.duty_cycle, retain = True)
                publish_rate = 0
            time.sleep(0.001)
        elif lux_value < light_densitiy_level_min:
            publish_rate += 1
            # If the light is too bright, turn it constant ON.
            led1_pwm.duty_cycle = 65535
            led2_pwm.duty_cycle = 65535
            led3_pwm.duty_cycle = 65535
            # Publish the light status to the MQTT Browser
            if publish_rate == publish_rate_max:
                mqtt_client.publish(output_feed_is_light, "true", retain = True)
                mqtt_client.publish(output_feed_light_densitiy, lux_value, retain = True)
                mqtt_client.publish(output_feed_light_densitiy_brightness, led1_pwm.duty_cycle, retain = True)
                publish_rate = 0
            time.sleep(0.001)
        else:
            publish_rate += 1
            # If the light is too bright, turn it OFF.
            led1_pwm.duty_cycle = 0
            led2_pwm.duty_cycle = 0
            led3_pwm.duty_cycle = 0
            # Publish the light status to the MQTT Browser
            if publish_rate == publish_rate_max:
                mqtt_client.publish(output_feed_is_light, "true", retain = True)
                mqtt_client.publish(output_feed_light_densitiy, lux_value, retain = True)
                mqtt_client.publish(output_feed_light_densitiy_brightness, led1_pwm.duty_cycle, retain = True)
                publish_rate = 0
            time.sleep(0.001)
    
        
    except Exception as e:
        mqtt_client.publish(output_feed_exception, f"Error: {e}", retain = True)
        mqtt_client.publish("iot/Project_light_const/$state", "not ready", retain = True)
        print(f"Error: {e}")
        time.sleep(3)
        #microcontroller.reset()