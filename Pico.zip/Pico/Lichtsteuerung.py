import board
import analogio
import digitalio
import mywifi
import mymqtt
import pwmio
import os
import time
from adafruit_datetime import datetime



#----------------- Definitions -----------------

# Connect to the MQTT Browser
mywifi.connect_wifi()
mqtt_client = mymqtt.connect_mqtt()

# LED
# use PWM to control the LED or use the digitalio to control the LED

#led_pin = board.GP0      # Replace with the GPIO pin connected to your LED
#PAR_SETPT = digitalio.DigitalInOut(led_pin)
#PAR_SETPT.direction = digitalio.Direction.OUTPUT

led1_pin = board.GP0      # Replace with the GPIO pin connected to your LED
led1_pwm = pwmio.PWMOut(led1_pin)

# Create an AnalogIn object for the selected pin
ldr = analogio.AnalogIn(board.GP28)



#----------------- MQTT -----------------

# Attention: Circuitpython does not have all the necessary libraries to loop the check for changes in the variables on the MQTT server. With local variables everything works. 
#            The following code provides topics for the variables on MQTT. The only thing we could not check is that if the variables change on the MQTT server, the local variables will update. 
#            There could be a problem with updating the variables. Adjust the code as needed


# Local variables

PAR_SETPT = 300
L_MAN = False
P_ACT = False
PAR_OND = '08:00'
PAR_OFFD = '20:00'



# Additional Definitions for Sun
sun_pin = board.GP18
sun_pwm = pwmio.PWMOut(sun_pin)

sun_delay = 2
sunset = False

#Sonnen-MEthode
def sun():
    global sun_delay, sunset

    if not sun_delay and sun_pwm.duty_cycle < 65535 and not sunset:
        sun_pwm.duty_cycle += 1
        sun_delay = 2
    else:
        if not sunset:
            sunset = True
        sun_pwm.duty_cycle -= 1
        if sun_pwm.duty_cycle == 0:
            sunset = False
        sun_delay = 2
    sun_delay -= 1


# Conversion of the Sensor value to Lux
def lux(analog_value):
    return analog_value * 0.032 - 17.166


# Here we define a function that checks if the current time is in the time slot
# We used adafruits datetime library to get the current time. For python we would use the 'normal' datetime library, which has addictional functions to get the current time. Adjust the code as needed
def is_current_time_in_timeslot(start_time_par, end_time_par):
    current_time = datetime.time()

    start_time = time(*map(int, start_time_par.split(':')))
    end_time = time(*map(int, end_time_par.split(':')))
    return start_time <= current_time <= end_time

start_time = PAR_OND
end_time = PAR_OFFD


# MQTT Topics
input_feed_P_ACT = "iot/Project_light_control/P_ACT"
input_feed_L_MAN = "iot/Project_light_control/L_MAN"
input_feed_PAR_OND = "iot/Project_light_control/PAR_OND"
input_feed_PAR_OFFD = "iot/Project_light_control/PAR_OFFD"

# Publishing MQTT topics
mqtt_client.publish("iot/Project_light_control/$Name", "Lichtsteuerung", retain=True)
mqtt_client.publish("iot/Project_light_control/$Ersteller", "Posch, Streicher, Zischg", retain=True)
mqtt_client.publish("iot/Project_light_control/$state", "not ready", retain=True)

mqtt_client.publish("iot/Project_light_control/P_ACT/$Name", "Präsenzerkennung", retain=True)
mqtt_client.publish("iot/Project_light_control/P_ACT/$Einheit", "None", retain=True)
mqtt_client.publish("iot/Project_light_control/P_ACT/$Datentyp", "bool", retain=True)

mqtt_client.publish("iot/Project_light_control/L_MAN/$Name", "Übersteuerung", retain=True)
mqtt_client.publish("iot/Project_light_control/L_MAN/$Einheit", "None", retain=True)
mqtt_client.publish("iot/Project_light_control/L_MAN/$Datentyp", "bool", retain=True)

mqtt_client.publish("iot/Project_light_control/PAR_OND/$Name", "Startzeit", retain=True)
mqtt_client.publish("iot/Project_light_control/PAR_OND/$Einheit", "None", retain=True)
mqtt_client.publish("iot/Project_light_control/PAR_OND/$Datentyp", "int", retain=True)

mqtt_client.publish("iot/Project_light_control/PAR_OFFD/$Name", "Stopzeit", retain=True)
mqtt_client.publish("iot/Project_light_control/PAR_OFFD/$Einheit", "None", retain=True)
mqtt_client.publish("iot/Project_light_control/PAR_OFFD/$Datentyp", "int", retain=True)


def on_message(mqtt_client, topic, message):
    global PAR_OFFD_value
    global PAR_OND_value
    global P_ACT
    global L_MAN

    if topic == input_feed_P_ACT:
        # P_ACT button simulation
        print("Received message on 'P_ACT':", bool(message))
        P_ACT = bool(message)
    elif topic == input_feed_L_MAN:
        # L             
        print("Received message on 'L_MAN':", bool(message))
        L_MAN = bool(message)
    elif topic == input_feed_PAR_OND:
        # PAR_OND value
        print("Received message on 'PAR_OND':", int(message))
        PAR_OND_value = int(message)
    elif topic == input_feed_PAR_OFFD:
        # PAR_OFFD value
        print("Received message on 'PAR_OFFD':", int(message))
        PAR_OFFD_value = int(message)

mqtt_client.on_message = on_message

mqtt_client.subscribe(input_feed_P_ACT, 0)
mqtt_client.subscribe(input_feed_L_MAN, 0)
mqtt_client.subscribe(input_feed_PAR_OND, 0)
mqtt_client.subscribe(input_feed_PAR_OFFD, 0)

mqtt_client.loop_start()


try:
    while True:
        sun()
        # Get the values from the MQTT topics
  
        H_ROOM = lux(ldr.value)
  
        print("E in Lux", H_ROOM)

        # Update PAR_SETPT value based on values
        if (P_ACT and H_ROOM < PAR_SETPT) or L_MAN: # Turn on the light
            if is_current_time_in_timeslot(start_time, end_time):
                led1_pwm.duty_cycle = 2 ** 15
                # The print statement is only for debugging purposes and to check if the system is working
                print("Licht ist an")

# If the user stops the program, the program will stop the MQTT client loop and the program will stop. We are not sure if this is the best option for handeling the MQTT client. Adjust the code as needed
except KeyboardInterrupt:
    pass

mqtt_client.loop_stop()
